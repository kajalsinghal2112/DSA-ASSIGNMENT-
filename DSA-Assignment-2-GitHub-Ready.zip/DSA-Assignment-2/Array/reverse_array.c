#include <stdio.h>
int main(void) {
    int a[100], n, i, temp;
    printf("Enter n: "); scanf("%d", &n);
    if (n < 1 || n > 100) return 1;
    printf("Enter elements: ");
    for (i = 0; i < n; i++) scanf("%d", &a[i]);
    for (i = 0; i < n / 2; i++) { temp = a[i]; a[i] = a[n - 1 - i]; a[n - 1 - i] = temp; }
    printf("Reversed: ");
    for (i = 0; i < n; i++) printf("%d ", a[i]);
    return 0;
}
